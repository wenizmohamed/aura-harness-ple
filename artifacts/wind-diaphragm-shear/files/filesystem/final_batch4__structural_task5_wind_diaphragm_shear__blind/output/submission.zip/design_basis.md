# Building A2 — Lateral Package Design Basis Narrative

**Project:** Northern Divide Data Campus — Building A2 (Lewis and Clark County, Montana)  
**Package:** Delegated Lateral Design — Roof Deck Diaphragm, Chords, Collectors, Shear Wall Loads & Precast Panel Connections  
**Design Method:** Allowable Stress Design (**ASD**, Load Combination `0.6W` for strength/drift; `0.6D + 0.6W` for panel stability)  
**Governing Criteria:** `EOR-NDDC-A2-S01` Rev 2 (14 August 2026) and `Spec 01 33 00` (14 August 2026)

---

## 1. Design Basis Parameter Table

Per Specification `01 33 00` Section 1.6, the design is built on the following governing parameters:

| item | value | source |
| --- | --- | --- |
| Kzt | 1.19 | TS-2026-02 Clause 4 & EOR-NDDC-A2-S01 Clause 4.3 |
| Ke | 0.8671 | ALTA-2025-77 Clause 1 (z_g = 3940.0 ft NAVD 88) & EOR-NDDC-A2-S01 Clause 4.4 |
| q_h_psf | 28.75 | EOR-NDDC-A2-S01 Clause 4.2 & WT-2026-07 Clause 3 (at h = 28.0 ft, V = 115 mph, Exp C, Kd = 0.85) |
| screen_wall_top_ft | 36.0 | SR-2026-118 Clause 5.2, A-301 Rev C, NDDC-A2_Federated_Model_2026.ifc & EOR-NDDC-A2-S01 Clause 5.3 |
| asbuilt_opening_panel | S14 | NDDC-A2_Federated_Model_2026.ifc (opening S14-O1), A-301 Rev C & EOR-NDDC-A2-S01 Clause 5.3 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 Clause 3.3 (0.6D + 0.6W for panel overturning stability per Clause 3.2 & 5.8) |
| omega_d | 2.35 | CDS-B36 Note 2 & EOR-NDDC-A2-S01 Clause 7.2 |
| analysis_method | semi-rigid (DIAPH-MT 1.0) | EOR-NDDC-A2-S01 Section 9, NDDC-AHJ-014 Clause 3 & OBD-NDDC-A2 Clause 4.1 |
| mesh_level | L2 | EOR-NDDC-A2-S01 Clause 9.1 & 9.7 (H = 5.0 ft, 1584 elements; L2 vs L3 W01 line W reaction diff = 0.23% <= 5%) |

---

## 2. Governing Wind Scenario by Wall Line

Per Specification `01 33 00` Section 1.6, the governing wind scenario for each exterior shear wall line is tabulated below:

| line | governing scenario |
| --- | --- |
| S | W07 |
| E | W10 |
| N1 | W08 |
| W | W01 |
| N2 | W03 |
| E2 | W01 |

*Note on Governing Scenarios (In-Plane Shear Wall Reaction vs. Perpendicular Roof-Level Line Load):*  
In the table above, the governing scenario is the wind scenario producing the maximum **in-plane shear wall reaction (`reaction_kips`)** taken out of the roof diaphragm (`S`: `W07` at `32.64 kips` [with `W03` at `31.85 kips`]; `E`: `W10` at `21.11 kips` [with `W05` at `21.06 kips` and `W01` at `20.74 kips`]; `N1`: `W08` at `11.03 kips` [with `W07` at `10.63 kips`]; `W`: `W01` at `47.85 kips`; `N2`: `W03` at `18.01 kips`; `E2`: `W01` at `46.30 kips`).  
When indexed by the maximum **perpendicular roof-level wind line load (`line_load_plf`)** delivered by the wall panels into the roof edge (`0.6W` ASD), the governing scenarios are:
- **Line `S`:** `W05` (`253.06 plf` ASD, $180^\circ$ South wind)
- **Line `E`:** `W03` (`253.42 plf` ASD, $90^\circ$ East wind)
- **Line `N1`:** `W01` (`321.78 plf` ASD, $0^\circ$ North wind)
- **Line `W`:** `W07` (`252.34 plf` ASD, $270^\circ$ West wind)
- **Line `N2`:** `W01` (`265.68 plf` ASD, $0^\circ$ North wind)
- **Line `E2`:** `W07` (`263.98 plf` ASD, $270^\circ$ West wind; `W03` gives `192.28 plf` suction)

---

## 3. Resolution of Conflicts Between Issued Documents

In accordance with `Spec 01 33 00` Section 1.6 and `T-204` Document Transmittal, every conflict among the issued documents in the package corpus was identified and resolved as follows:

1. **Governing Structural Design Criteria (`EOR-NDDC-A2-S01` Rev 2 vs. Rev 0):**
   - *Conflict:* `project/90_archive/EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev0_SUPERSEDED.pdf` (dated 3 May 2024) specified preliminary parameters including Risk Category II, basic wind speed $V = 105\text{ mph}$, $K_{zt} = 1.00$, $K_e = 1.00$, LRFD/flexible diaphragm assumptions, and a clean $240\text{ ft} \times 180\text{ ft}$ rectangle.
   - *Resolution:* `project/30_structural/EOR-NDDC-A2-S01_Structural_Design_Criteria_Rev2.pdf` (dated 14 August 2026) explicitly supersedes Revision 0 (`T-204` Note 1 vs. Item 12) and governs all aspects of the lateral package.

2. **Risk Category, Basic Wind Speed, and Diaphragm Idealization (`NDDC-AHJ-014` & `OBD-NDDC-A2` vs. 2024 Pre-Application Memo & `HallB_Lateral_Study_2023.pdf`):**
   - *Conflict:* The 2024 pre-application memorandum used $V = 105\text{ mph}$ at Risk Category II, and `project/90_archive/HallB_Lateral_Study_2023.pdf` analyzed a different building on campus (Building A1 / Data Hall B) using a flexible-diaphragm tributary width approach.
   - *Resolution:* `NDDC-AHJ-014` (11 June 2026, Clauses 1–4) and `OBD-NDDC-A2` (adopting `UFC 3-301-01` Table 2-2) establish **Risk Category III**, **$V = 115\text{ mph}$** (3-second gust), **Exposure C**, **$K_d = 0.85$**, and mandate a **semi-rigid finite-element diaphragm analysis (`DIAPH-MT 1.0`)**, explicitly rejecting flexible-diaphragm tributary distribution and superseding the 2024 pre-application memo (`T-204` Item 15).

3. **Topographic Factor $K_{zt}$ (`TS-2026-02` vs. 2024 Preliminary Criteria):**
   - *Conflict:* The 2024 preliminary criteria assumed $K_{zt} = 1.00$.
   - *Resolution:* The site-specific topographic wind study `TS-2026-02` (30 April 2026, Clauses 4–5), `NDDC-AHJ-014` Clause 2, and `EOR-NDDC-A2-S01` Rev 2 Clause 4.3 establish **$K_{zt} = 1.19$** over the entire Building A2 footprint at all elevations and azimuths, superseding $K_{zt} = 1.00$.

4. **Site Elevation and Ground Elevation Factor $K_e$ (`ALTA-2025-77` vs. 2024 Preliminary Criteria):**
   - *Conflict:* The 2024 preliminary criteria took $K_e = 1.00$ without reduction for site elevation.
   - *Resolution:* `ALTA-2025-77` (18 November 2025, Clause 1) establishes Building A2 finished floor elevation `FF-A2` at **$z_g = 3940.0\text{ ft}$ NAVD 88**, and `EOR-NDDC-A2-S01` Rev 2 Clause 4.4 mandates **$K_e = e^{-0.0000362 z_g} = e^{-0.0000362(3940.0)} = 0.867077$** (`0.8671`), resulting in $q_h = 28.7458\text{ psf}$ (`28.75 psf`) at $h = 28.0\text{ ft}$.

5. **As-Built Roof Plan Footprint — NE Generator Yard Re-Entrant Notch & Mechanical Well (`A-101` Rev C & `S-201` Rev C vs. `A-101` Rev A):**
   - *Conflict:* `project/90_archive/A-101_Roof_Plan_RevA_SUPERSEDED.dxf` (2024) showed an un-notched $240\text{ ft} \times 180\text{ ft}$ rectangular roof ($43,200\text{ sf}$).
   - *Resolution:* `A-101` Rev C (2026), `S-201` Rev C (2026), and `EOR-NDDC-A2-S01` Rev 2 Clause 4.5 govern (`T-204` Notes 7, 9 vs. Item 13). The as-built roof excludes the $60\text{ ft} \times 40\text{ ft}$ NE generator-yard notch ($x \in [180, 240]\text{ ft}, y \in [140, 180]\text{ ft}$) and the $40\text{ ft} \times 30\text{ ft}$ interior mechanical well opening ($x \in [100, 140]\text{ ft}, y \in [100, 130]\text{ ft}$), giving a net diaphragm deck area of **$39,600\text{ sf}$** and six exterior wall lines (`S, E, N1, W, N2, E2`).

6. **As-Built North Mechanical Screen Wall Elevation (`SR-2026-118`, `A-301` Rev C & 2026 IFC Model vs. `PC-S01` 2024 Schedule & `PC-S02` Rev 1):**
   - *Conflict:* `PC-S01_Precast_Panel_Schedule_2024.xlsx` and `PC-S02_Precast_Panel_Elevations_Rev1_SUPERSEDED.dxf` listed all north elevation panels at a top elevation of $+31.00\text{ ft}$ ($3.0\text{ ft}$ parapet).
   - *Resolution:* `SR-2026-118` (18 August 2026, Clause 5.2), `Roof_Line_Scan_2026-08-14.ply`, `A-301` Rev C, `NDDC-A2_Federated_Model_2026.ifc`, and `EOR-NDDC-A2-S01` Rev 2 Clause 5.3 confirm that panels **`N108`, `N109`, `N110`, and `N111`** ($x = 96\text{ ft}$ to $168\text{ ft}$ on line `N1`) extend to **`+36.00 ft`** above finished floor ($8.00\text{ ft}$ cantilever above the $+28.00\text{ ft}$ roof deck), experiencing velocity pressure $q_p(36\text{ ft}) = 30.31\text{ psf}$ per `WT-2026-07` Clause 6.3.

7. **As-Built Field-Cut Opening in Panel `S14` (`NDDC-A2_Federated_Model_2026.ifc` & `A-301` Rev C vs. `PC-S01` 2024 Schedule & `PC-S02` Rev 2):**
   - *Conflict:* The 2024 precast schedule `PC-S01` (Note 4: *"Field openings cut after erection are not shown on this schedule"*; marked *"superseded by the federated model"* in `T-204` Item 10) and `PC-S02` Rev 2 (Note 4) show panel `S14` ($x = 192.0\text{ ft}$ to $204.0\text{ ft}$ on line `S`) as a solid $12.0\text{ ft}$ panel.
   - *Resolution:* `NDDC-A2_Federated_Model_2026.ifc` (`IFCVOIDINGFEATURE` `S14-O1`), `A-301` Rev C, and `EOR-NDDC-A2-S01` Rev 2 Clause 5.3 govern: panel **`S14`** has an $8.0\text{ ft}$ wide by $12.0\text{ ft}$ high field-cut louver opening from $x = 194.5\text{ ft}$ to $202.5\text{ ft}$ ($z = 0$ to $12.0\text{ ft}$). This splits `S14` into a west leg of width $2.5\text{ ft} \ge 2.0\text{ ft}$ (retained as active pier `S14`, $k = 13.34\text{ kip/in}$) and an east leg of width $1.5\text{ ft} < 2.0\text{ ft}$ (neglected per `EOR-NDDC-A2-S01` Clause 5.4).

8. **Deck Span Stiffness Adjustment in Zone `Z22` (`SJ-201` Note 2 & `CDS-B36` Note 4):**
   - *Conflict:* Standard roof joists run N-S at $5\text{ ft}$ o.c. with a typical $6\text{ ft}$ deck span (`SJ-201` Note 1), for which `CDS-B36` Table 3 tabulates $G'$.
   - *Resolution:* Per `SJ-201` Note 2, joists in mechanical bay zone `Z22` are doubled to create a $4\text{ ft } 0\text{ in}$ deck span. Per `CDS-B36` Note 4 and `EOR-NDDC-A2-S01` Clause 7.3, the tabulated $G'$ in `Z22` is multiplied by **$1.15$** ($G'_\text{used} = 1.15 \times 17.8 = 20.47\text{ kip/in}$ for `D22-36/4-2`), while nominal shear strength $V_\text{nom} = 980\text{ plf}$ ($V_\text{ASD} = 417.02\text{ plf}$) is unchanged.
