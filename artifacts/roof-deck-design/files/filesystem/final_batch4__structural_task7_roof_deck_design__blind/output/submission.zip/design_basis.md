# Roof Deck Structural Design Basis — DC-2 Helena Data Centre (Building A)

## 1. Executive Summary

This report documents the structural engineering design basis for the main roof steel deck of **Building A** at the **DC-2 Helena Data Centre** in Lewis and Clark County, Montana (`DC2-2026-014`, site elevation `4,880 ft`). The roof covers a `240 ft × 180 ft` footprint (`43,200 sf` gross; `42,192 sf` net decked area after excluding three framed openings totaling `1,008 sf` on the `6 ft × 6 ft` checking grid) supported by fixed `26K9` open-web steel joists at `6 ft-0 in` on centre spanning `30 ft-0 in` between `36G 5N 15.0K` joist girders.

The roof deck is designed using **NORDECK B-36** (`1.5 in` deep Type B wide-rib G60 galvanized steel deck, `36 in` cover width, $F_y = 40\text{ ksi}$, $F_u = 55\text{ ksi}$, $E = 29,500\text{ ksi}$) in three-span continuous condition across all ten project design scenarios (`S01`–`S10`). The optimized design partitions the roof into **3 zones** and **14 non-overlapping rectangles** using **2 deck gages** (`18 gage` and `22 gage`) and **3 attachment patterns**:
- **Zone `Z1`** (`8,640 sf`, 2 rectangles along the West `x = 0..18 ft` and East `x = 210..240 ft` bands): **18 gage**, `36/9` support fasteners (`HX-12`), `SCREW-10` sidelap screws at `5` per span ($S_n = 1,751\text{ plf}$, $\phi_d S_n = 1,225.70\text{ plf}$, $G' = 45.6\text{ kip/in}$).
- **Zone `Z2`** (`15,768 sf`, 5 rectangles covering low-drift perimeter and interior regions): **22 gage**, `36/9` support fasteners (`HX-12`), button-punched (`BP`) sidelaps at `4` per span ($S_n = 745\text{ plf}$, $\phi_d S_n = 521.50\text{ plf}$, $G' = 17.6\text{ kip/in}$).
- **Zone `Z3`** (`17,784 sf`, 7 rectangles covering interior snow-drift and opening-adjacent regions): **18 gage**, `36/7` support fasteners (`HX-12`), `SCREW-10` sidelap screws at `3` per span ($S_n = 1,061\text{ plf}$, $\phi_d S_n = 742.70\text{ plf}$, $G' = 26.8\text{ kip/in}$).

The total installed cost at the Cost Plan (`CP-RD-2026 Rev 0`) rates is **$218,128.36** (`$164,886.48` deck supply and erection + `$33,101.88` installed support fasteners and sidelap connectors + `$20,140.00` indirect set-up costs).

---

## 2. Governing Documents & Conflict Resolution

Per Document Transmittal `T-118`, `OBD-DC2-A`, and `EOR-DC-RD-01 Rev 2` Sections 1–2, conflicts among the project documents were resolved as follows:

1. **Structural Design Criteria (`EOR-DC-RD-01 Rev 2` dated 31 July 2026 vs. withdrawn `Rev 1` in `archive/`)**:
   - Per `T-118` Section 1 & Clause 3.3, `EOR-DC-RD-01 Rev 2` is the current issue for construction and supersedes `Rev 1` in its entirety. `Rev 2` rewrites Clause 4.2 to require the unreduced roof live load $L_r = 20\text{ psf}$ on the deck (`18 sq ft` panel tributary area $\le 200\text{ sq ft}$), rewrites Clause 5.4 to specify windward (`0.75 hd`) and leeward (`1.0 hd`) drift rules across all four wind directions, rewrites Clause 7.2 to include $20\%$ of the balanced flat-roof snow load $p_f$ in the effective seismic weight (since $p_f = 43.66\text{ psf} > 30\text{ psf}$), and adds Clauses 9.3 and 10.4.
2. **Ground Snow Load (`SNOW-2026-014 Rev 0`)**:
   - Per `OBD-DC2-A` Section 9 and `EOR-DC-RD-01 Rev 2` Clause 2.2 & Clause 5.1, the AHJ-accepted site-specific study `SNOW-2026-014` Table 6-1 establishes **$p_g = 63.0\text{ psf}$** at the `4,880 ft` site elevation on a Risk Category II basis (`UFC 3-301-01` Section 2-4.5 / IBC Section 1608.2.3). The Risk Category III snow importance factor $I_s = 1.10$ is applied once in `EOR-DC-RD-01 Rev 2` Clause 5.1.
3. **Seismic Ground Motion Hazard (`USGS_ASCE7-22_RC-III_SiteClass-D_46.6832_-111.9756.json` vs. 2019 preliminary JSON)**:
   - The ASCE 7-22 Risk Category III, Site Class D hazard report (`SDS = 0.44 g`, `SD1 = 0.24 g`, `SDC = D`) governs over the superseded 2019 ASCE 7-16 Risk Category II, Site Class C preliminary file.
4. **3D Structural Model (`DC2-A-STR_Roof_Structure_Model_RevC.ifc`) & Current Drawings (`A-201 Rev C`, `M-401 Rev C`, `S-101 Rev 3`, `S-501 Rev 2`) vs. Withdrawn `A-201 Rev B`**:
   - Per `T-118` Clauses 3.1–3.2 and `A-201 Rev C` Note 5, the 3D structural coordination model `DC2-A-STR Rev C` and current drawings `A-201 Rev C`, `M-401 Rev C`, and `S-101 Rev 3` govern roof geometry. Withdrawn `A-201 Rev B` (which showed `SCR-N` at its earlier $y = 158\text{ ft}$ position instead of the governing $y = 164\text{ ft}$ position) was excluded.
   - Non-project rows in `Rooftop_Equipment_Schedule.xlsx` for adjacent existing facility `DC-1 Building B` (`DC1-RTU-11`, `DC1-EF-3`) were excluded per the schedule header note.
   - Framed opening `RO-3` (`x = 180..210 ft`, `y = 60..80 ft`) spans across `y = 60..80 ft` and touches the `6 ft × 6 ft` cells in `y = 78..84 ft`; per the grid checking conventions, all 20 cells in `x = 180..210 ft`, `y = 60..84 ft` (`720 sf`), together with `RO-1` (`x = 96..108 ft`, `y = 48..60 ft`, `144 sf`) and `RO-2` (`x = 132..144 ft`, `y = 120..132 ft`, `144 sf`), carry no deck.
5. **Procurement Lead Time (`Deck_Stock_Availability_2026-07.xlsx` & `OBD-DC2-A` Section 5)**:
   - `16 gage` deck requires a `14-week` mill order, violating the `9-week` maximum release-to-site allowance in `OBD-DC2-A` Section 5. Only stocked gages (`22 gage` at `2 weeks`, `20 gage` at `3 weeks`, and `18 gage` at `4 weeks`) are eligible.

---

## 3. Gravity, Snow Drift, Wind Uplift & Seismic Design Basis

### 3.1 Dead Load, Roof Live Load & Balanced Snow Load
- **Collateral Dead Load** (`EOR-DC-RD-01 Rev 2` Section 3): $4.5\text{ psf}$ (roofing, 3 in polyiso insulation, cover board) $+ 6.0\text{ psf}$ (suspended MEP allowance) $= 10.5\text{ psf}$. Adding deck self-weight (`1.6 psf` for 22 ga, `2.5 psf` for 18 ga per `NORDECK B-36` Table 2-1), total dead load is **$12.10\text{ psf}$** (22 ga) and **$13.00\text{ psf}$** (18 ga).
- **Roof Live Load** (`EOR-DC-RD-01 Rev 2` Clauses 4.1–4.2 & `UFC 3-301-01` Table E-1 Item 51): **$L_r = 20.0\text{ psf}$** unreduced ($R_1 = 1.0$, $R_2 = 1.0$).
- **Balanced Flat-Roof Snow Load** (`SNOW-2026-014` Table 6-1 & `EOR-DC-RD-01 Rev 2` Clauses 5.1–5.3):
  $$p_g = 63.0\text{ psf}, \quad C_e = 0.90, \quad C_t = 1.0, \quad I_s = 1.10$$
  $$p_f = 0.7 C_e C_t I_s p_g = 0.7 (0.90)(1.0)(1.10)(63.0) = 43.659\text{ psf} \rightarrow \mathbf{43.66\text{ psf}}$$
  $$\gamma = \min(0.13 p_g + 14, 30) = 0.13(63.0) + 14 = \mathbf{22.19\text{ pcf}}, \quad h_b = \frac{p_f}{\gamma} = \mathbf{1.968\text{ ft}}$$

### 3.2 Snow Drifts at Roof Projections (`S02`, `S03`, `S04`)
Per `EOR-DC-RD-01 Rev 2` Clauses 5.4–5.5, $h_d(\ell_u) = 0.43 \ell_u^{1/3} (p_g + 10)^{1/4} - 1.5\text{ ft}$ with $\ell_u \ge 20\text{ ft}$, windward drift height $0.75 h_d(\ell_{u,\text{fetch}})$, leeward drift height $1.00 h_d(\ell_{u,\text{obstruction}})$, full width $w = 4 h_d$ when $h_d \le h_c$, and truncated peak $h_c \gamma$ with width $w = \min(4 h_d^2 / h_c, 8 h_c)$ when $h_d > h_c$:

| Location | Face | Governing Drift Mechanism & Upwind Fetch $\ell_u$ | Clear Height $h_c = h - h_b$ (ft) | Drift Height $h_d^*$ (ft) | Drift Width $w$ (ft) | Peak Surcharge $p_d$ (psf) | Plan Band (`from` $\rightarrow$ `to`, ft) |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :---: |
| **`MEP-PH-1`** | `W` | Leeward ($\ell_u = 120.0\text{ ft}$ along-wind enclosure length) | $10.032$ | $4.700$ | $18.80$ | **`104.28`** | `60.0` $\rightarrow$ `41.20` |
| **`SCR-N`** | `S` | Windward ($\ell_u = 164.0\text{ ft}$ South roof fetch, truncated at $h_c$) | $4.032$ | $4.032$ ($h_c$) | $16.25$ | **`89.48`** | `164.0` $\rightarrow$ `147.75` |
| **`PARAPET`** | `N` | Windward ($\ell_u = 180.0\text{ ft}$ roof fetch, truncated at $h_c$, $w = 8 h_c$) | $1.532$ | $1.532$ ($h_c$) | $12.26$ | **`34.01`** | `180.0` $\rightarrow$ `167.74` |
| **`RTU-1`** | `E` | Windward ($\ell_u = 204.0\text{ ft}$ East roof fetch to $x = 36\text{ ft}$) | $5.032$ | $4.424$ | $17.70$ | **`98.17`** | `36.0` $\rightarrow$ `53.70` |

### 3.3 Wind Velocity Pressure & C&C Uplift (`S09`)
- Per `EOR-DC-RD-01 Rev 2` Clauses 6.1–6.2, at $V = 115\text{ mph}$, Exposure C, $h = 32.0\text{ ft}$ ($K_z = 1.04$, $K_{zt} = 1.0$, $K_d = 0.85$, $K_e = 1.0$):
  $$q_h = 0.00256 (1.04)(1.0)(0.85)(1.0)(115)^2 = \mathbf{29.93\text{ psf}}, \quad a = \max(\min(0.1 \times 180, 0.4 \times 32), 0.04 \times 180, 3.0) = \mathbf{12.8\text{ ft}}\text{ (2a = 25.6 ft)}$$
- Under LRFD uplift combination `0.9D + 1.0W` (`Clause 6.2.3` & `Section 8.1`), resisting dead load (excluding the `6.0 psf` suspended MEP allowance) is $0.9 (4.5 + w_{\text{deck}}) = 5.49\text{ psf}$ (22 ga) and $6.30\text{ psf}$ (18 ga). With $\phi_t = 0.50$ (`Clause 10.1`) and `NORDECK B-36` Table 6-1, design fastener tension capacity is $\phi_t P_{nov} = 149.0\text{ lb}$ (22 ga) and $239.5\text{ lb}$ (18 ga):
  - **Zone `Z1`** (18 ga, `36/9` in Corner Zone 3, gross uplift $101.20\text{ psf}$): net attachment demand $= 101.20 - 6.30 = \mathbf{94.90\text{ psf}} \le$ fastener capacity $\mathbf{119.75\text{ psf}}$ (D/C $= 0.792$).
  - **Zone `Z2`** (22 ga, `36/9` in Perimeter Zone 2, gross uplift $74.20\text{ psf}$): net attachment demand $= 74.20 - 5.49 = \mathbf{68.71\text{ psf}} \le$ fastener capacity $\mathbf{74.50\text{ psf}}$ (D/C $= 0.922$).
  - **Zone `Z3`** (18 ga, `36/7` in Perimeter Zone 2, gross uplift $74.20\text{ psf}$): net attachment demand $= 74.20 - 6.30 = \mathbf{67.90\text{ psf}} \le$ fastener capacity $\mathbf{93.14\text{ psf}}$ (D/C $= 0.729$).

### 3.4 Effective Seismic Weight & Lateral Forces (`S05`–`S08`, `S10`)
- Per `EOR-DC-RD-01 Rev 2` Clauses 7.1–7.4 and `LAT-2026-003 Rev 1` Sections 4–5:
  $$S_{DS} = 0.44, \quad I_e = 1.25, \quad R = 3.25, \quad \Omega_0 = 2.0, \quad w_{\text{seismic}} = 18.0 + 0.20(43.66) = \mathbf{26.732\text{ psf}} \rightarrow \mathbf{26.73\text{ psf}}$$
  $$W = 26.732 \times \frac{43,200}{1,000} = 1,154.82\text{ kip}, \quad C_s = \frac{0.44 \times 1.25}{3.25} = 0.16923, \quad F_{px} = C_s W = \mathbf{195.43\text{ kip}}$$
  $$\text{WIND\_X} = \mathbf{118.0\text{ kip}}, \quad \text{WIND\_Y} = \mathbf{152.0\text{ kip}}$$

---

## 4. In-Plane Diaphragm Analysis, Stiffness Tuning & Classification

The roof diaphragm was analysed using the 2D finite-element formulation described in `LAT-2026-003 Rev 1` Sections 6–8:
- **Shear Panels**: `40 × 6 = 240` shear panels (`6 ft × 30 ft` each) on a `41 × 7 = 287` node grid (`574` DOFs). Within each `6 ft × 30 ft` panel, the five `6 ft × 6 ft` cells carry constant shear flow in series, with framed opening cells (`RO-1`, `RO-2`, `RO-3`) excluded (`G' = 0`).
- **Axial Framing & Edge Bars**: Joist lines (`EA = 87,580 kip`), joist girder lines (`EA = 221,850 kip`), and continuous `L5x3-1/2x5/16` perimeter edge angles (`EA = 74,240 kip`).
- **Braced Frame Springs**: Half of each frame's stiffness at each of its two column nodes (`BF-X1, BF-X2`: `2 × 27.5 kip/in` on Grid A; `BF-X3, BF-X4`: `2 × 9.0 kip/in` on Grid G; `BF-Y1, BF-Y2`: `2 × 11.0 kip/in` on Grid 1; `BF-Y3, BF-Y4`: `2 × 34.0 kip/in` on Grid 9). Regularisation springs (`10^-4 kip/in`) carry `< 0.01%` of the applied force (`<< 2%` limit).

### Stiffness Distribution & Collector Force Control (`S10`)
Because the South wall braced frames (`BF-X1`, `BF-X2`, combined stiffness `110.0 kip/in`) are more than three times stiffer than the North wall braced frames (`BF-X3`, `BF-X4`, combined stiffness `36.0 kip/in`), an overly stiff interior diaphragm (`G' > 35 kip/in` across `x = 66..180 ft`) draws excessive seismic shear into the South wall collector splice at `x = 60 ft` (Grid A, inner end of `BF-X1`), causing the $\Omega_0 = 2.0$ amplified collector force to exceed the `58.0 kip` bolted splice capacity (`LAT-2026-003` Table 6-1 & Clause 6.2.1). By pairing stiff end zones (`Z1`, $G' = 45.6\text{ kip/in}$ along `x = 0..18 ft` and `x = 210..240 ft`) with moderate-stiffness interior zones (`Z2` with button-punched sidelaps at $G' = 17.6\text{ kip/in}$ and `Z3` with `36/7, SCREW-10, 3` at $G' = 26.8\text{ kip/in}$), the diaphragm satisfies all shear strength checks while limiting the amplified `S10` collector force to **`56.45 kip <= 58.0 kip`**, the maximum `S08` chord force to **`29.69 kip <= 38.0 kip`**, and the maximum `S08` in-plane diaphragm deflection to **`1.322 in <= 1.60 in`**.

### Diaphragm Classification (`SEMI-RIGID`)
Across all lateral scenarios (`S05`, `S06`, `S07`, `S08`, `S10`), the maximum in-plane diaphragm deflection (`0.502 in` to `1.322 in`) is well below `2.0` times the average storey drift of the vertical braced frames (`1.48 in` in X, `1.68 in` in Y; ratio $\le 0.79 < 2.0$). Per `EOR-DC-RD-01 Rev 2` Clause 9.3, the diaphragm is classified as **`SEMI-RIGID`**.

| Scenario | Direction | Max Shear Demand (plf) | Max In-Plane Deflection (in) | Max Chord Force (kip) | Max Collector Force (kip) | Classification |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **`S05`** | `X` | `399.76` | `0.502` | `11.58` | `15.70` | `SEMI-RIGID` |
| **`S06`** | `Y` | `699.07` | `1.036` | `23.00` | `16.54` | `SEMI-RIGID` |
| **`S07`** | `X` | `669.88` | `0.806` | `19.28` | `28.23` | `SEMI-RIGID` |
| **`S08`** | `Y` | `912.90` | `1.322` | `29.69` | `21.85` | `SEMI-RIGID` |
| **`S10`** | `X` | `669.88` | `0.806` | `19.28` | **`56.45`** ($\le 58.0$) | `SEMI-RIGID` |

---

## 5. Zoning Summary, Serviceability & Bill of Materials

- **Vertical Deflection (`Clause 9.1`)**: Maximum 3-span live/snow deflection $\delta = 0.0069 w L^4 / (E I_x)$ is `0.155 in` in `Z2` (22 ga, snow load $91.41\text{ psf}$) and `0.149 in` in `Z3` (18 ga, snow load $147.94\text{ psf}$), both well below $L/240 = 0.30\text{ in}$.
- **End Bearing & Web Crippling (`Clause 10.6` & `Table 4-1`)**: Maximum end reaction $0.4 w_{\text{tot}} L$ is `248 lb/ft <= 1,180 lb/ft` (22 ga) and `386 lb/ft <= 2,310 lb/ft` (18 ga).
- **Boundary & Opening Attachment (`Clause 10.4`)**: Every zone (`Z1`, `Z2`, `Z3`) uses $\ge 36/7$ support fasteners and $\ge 3$ sidelap connectors per span.

| Zone | Gage | Attachment Pattern | Area (sf) | Rectangles | Max Shear Demand / Cap (plf) | Max Gravity Demand / Cap (psf) | Net Uplift Demand / Cap (psf) | Governing Scenario & D/C Ratio |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **`Z1`** | `18` | `36/9`, `SCREW-10`, `5`/span | `8,640` | `2` | `912.90 / 1225.70` (`0.745`) | `157.14 / 177.00` (`0.888`) | `94.90 / 119.75` (`0.792`) | **`S04`** (`0.888`) |
| **`Z2`** | `22` | `36/9`, `BP`, `4`/span | `15,768` | `5` | `476.21 / 521.50` (`0.913`) | `103.51 / 106.00` (`0.976`) | `68.71 / 74.50` (`0.922`) | **`S04`** (`0.976`) |
| **`Z3`** | `18` | `36/7`, `SCREW-10`, `3`/span | `17,784` | `7` | `600.53 / 742.70` (`0.809`) | `160.94 / 177.00` (`0.909`) | `67.90 / 93.14` (`0.729`) | **`S02`** (`0.909`) |

### Bill of Materials & Installed Cost Breakdown (`CP-RD-2026 Rev 0`)
- **`deck area 22 gage`**: `15,768 sf` (`2 weeks` lead time, ex stock) $\times \$3.05/\text{sf} = \$48,092.40$
- **`deck area 18 gage`**: `26,424 sf` (`4 weeks` lead time, ex stock) $\times \$4.42/\text{sf} = \$116,794.08$
- **`support fasteners`** (`HX-12`): `19,120 ea` $\times \$1.35/\text{ea} = \$25,812.00$
- **`sidelap connectors`**: `8,868 ea` total (`5,364 ea` `SCREW-10` $\times \$1.15/\text{ea} = \$6,168.60$ + `3,504 ea` `BP` $\times \$0.32/\text{ea} = \$1,121.28$)
- **Indirect Set-Up Costs**: `3 zones` ($\$2,700$) + `14 rectangles` ($\$3,640$) + `2 gages` ($\$9,600$) + `3 patterns` ($\$4,200$) $= \$20,140.00$
- **Total Installed Cost**: **`$218,128.36`**
