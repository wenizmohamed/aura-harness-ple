```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01 (1 September 2022, Change 4 of 17 December 2024)",
    "precedence": "Most restrictive requirement governs (EDS-26 Rev 4 Section 1.1 and Sheet G-001); where EDS-26 Rev 4 is silent, UFC 3-501-01 and UFC 3-520-01 govern."
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42,
    "roof_ambient_c": 46,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "encasement_thermal_resistivity_k_m_w": 0.55,
    "solar_irradiance_w_m2": 1030
  },
  "sources": {
    "codes_of_record": "drawings/G-001_code_of_record_and_general_notes.dxf; criteria/UFC_1-200-01_DoD_Building_Code_2024-12-17.pdf; owner/NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 1.1",
    "outdoor_design_dry_bulb_c": "site/NOAA_daily_normals_1991-2020_USW00003145.csv (max DLY-TMAX-NORMAL = 106.8 F = 41.56 C rounded up to 42 C per EDS-26 Rev 4 Section 5.4)",
    "roof_ambient_c": "owner/NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 5.4 (outdoor dry-bulb 42 C + 4 K = 46 C); site/M-501-C_ambient_temperature_coordination_memo.pdf Section 3",
    "earth_ambient_c": "site/NOAA_daily_normals_1991-2020_USW00003145.csv (annual mean DLY-TAVG-NORMAL = 76.00 F = 24.45 C + 3 K = 27.45 C per EDS-26 Rev 4 Section 5.3.2)",
    "soil_thermal_resistivity_k_m_w": "site/GEO-4210-T_thermal_resistivity_report.pdf Section 3.1 (Fluidized thermal backfill 0.60 K*m/W placed full trench width and depth; native clay 0.95 K*m/W rejected per EDS-26 Rev 4 Section 5.3.3); drawings/E-619_duct_bank_sections.dxf",
    "encasement_thermal_resistivity_k_m_w": "site/GEO-4210-T_thermal_resistivity_report.pdf Section 3.2 (3000 psi concrete encasement 0.55 K*m/W); owner/NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 5.3.3",
    "solar_irradiance_w_m2": "owner/NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Section 5.4 (1030 W/m2, absorptivity 0.6, h = 14.0 W/(m2*K)); site/M-501-C_ambient_temperature_coordination_memo.pdf Section 3"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs (utility pad-mount transformer secondary bushings, point of government ownership per WRPU_service_availability_letter.pdf and UFC 3-501-01 Section 3-2.7.4.1)",
    "transformer_reset": false,
    "feeder_chain_pct": {
      "SE-1_to_MSB-1": 1.04,
      "SE-1_F-01_to_MCC-1": 2.58,
      "SE-1_F-02_to_DP-2": 1.41,
      "SE-1_F-02_F-06_to_K-13": 1.57,
      "SE-1_F-02_F-06_F-07_to_LP-1": 2.77,
      "SE-1_F-05_to_DP-3": 2.58,
      "SE-1_F-10_to_ATS-1": 2.78
    },
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 93384.42,
    "termination_usd": 9609.32,
    "raceway_usd": 47589.6,
    "material_usd": 96898.77,
    "labor_usd": 53684.57,
    "total_usd": 150583.34
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D5",
      "D6",
      "D9",
      "D10"
    ],
    "F-10": [
      "D4",
      "D8"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": 31.09
}
```

# Basis of Design — Low-Voltage Wire Schedule (Building 4210, Project P-4210)

## 1. Codes of Record, Adopting Criteria, and Order of Precedence

This wire schedule and calculation package for Building 4210 (Consolidated Support Facility) at Naval Support Activity Whitmore Ridge was prepared against the codes and standards in effect at the start of design (**14 July 2025**, per Sheet `G-001_code_of_record_and_general_notes.dxf` and `NSA-WR_EDS-26_electrical_design_standard_rev4.pdf` §1.1):

1. **Adopting Document:** **UFC 1-200-01** (*DoD Building Code*, 1 September 2022, Change 4 of 17 December 2024).
2. **Building Code of Record:** **IBC 2024 Edition** (*International Building Code*), adopted and modified by `UFC 1-200-01`.
3. **Electrical Code of Record:** **NFPA 70 (NEC) 2023 Edition** (*National Electrical Code*), adopted via `UFC 1-200-01` §1-6.2 and **UFC 3-501-01** (*Electrical Engineering*, 27 November 2024).
4. **Governing Federal Criteria:** **UFC 3-501-01** (27 November 2024), **UFC 3-520-01** (*Interior Electrical Systems*, 16 January 2025), and **UFC 1-200-02** (referencing ASHRAE 90.1).
5. **Installation Design Standard:** **NSA-WR EDS-26 Revision 4** (*Electrical Design Standard — Building Distribution*, 12 June 2026).
6. **Contract Specifications:** Section **26 05 19** (*Low-Voltage Electrical Power Conductors and Cables*, fixing **Cascadia Wire & Cable Section 4, Issue 2026-1** as the Basis of Design), Section **26 05 33** (*Raceways and Boxes for Electrical Systems*), and Section **26 24 16** (*Panelboards*).

**Order of Precedence & Document Resolution:** Per Sheet `G-001` and `NSA-WR EDS-26 Rev 4` §1.1, where two governing documents set different limits on the same quantity, **the more restrictive requirement governs**; where `EDS-26 Rev 4` is silent, the applicable UFC governs. Superseded or non-governing documents in the data room were explicitly excluded from governing decisions:
- `owner/NSA-WR_EDS-26_electrical_design_standard_rev2_SUPERSEDED.pdf` (superseded on 12 June 2026 by Revision 4).
- `drawings/E-601_one_line_REV_A_SUPERSEDED.pdf` (superseded by IFC drawing `E-601_one_line_diagram.dxf`).
- `vendor/Meridian_Cable_building_wire_datasheet.pdf` (not the Basis of Design under Specification `26_05_19_low_voltage_conductors.pdf` §1.3).
- `drawings/E-401_fire_alarm_riser.dxf` (power-limited fire alarm circuits excluded from scope per `E-401` note and `EDS-26 Rev 4` §1).

---

## 2. Environmental Parameters and Provenance

- **Outdoor Design Dry-Bulb (`outdoor_design_dry_bulb_c = 42 °C`):** From `site/NOAA_daily_normals_1991-2020_USW00003145.csv`, the highest daily normal maximum (`DLY-TMAX-NORMAL`) is `106.8 °F` (`41.556 °C`). Per `EDS-26 Rev 4` §5.4, rounding up to the next whole degree Celsius gives **`42 °C`**.
- **Roof Cable Tray Ambient (`roof_ambient_c = 46 °C`) & Solar Irradiance (`solar_irradiance_w_m2 = 1030 W/m²`):** Per `EDS-26 Rev 4` §5.4 and `site/M-501-C_ambient_temperature_coordination_memo.pdf` §3, unshaded roof ladder tray `CT-R1` has ambient `42 °C + 4 K = 46 °C`, solar irradiance `S = 1030 W/m²`, absorptivity `alpha_s = 0.6`, and convection coefficient `h = 14.0 W/(m²·K)` (`Delta_T_s = 14.05 K`).
- **Undisturbed Earth Ambient (`earth_ambient_c = 27.45 °C`):** Per `EDS-26 Rev 4` §5.3.2, undisturbed earth ambient is the annual mean of `DLY-TAVG-NORMAL` (`76.004 °F = 24.446 °C`) plus `3 K` = **`27.45 °C`**. Spot temperature logger readings (`22.1–28.4 °C` in `GEO-4210-T_thermal_resistivity_report.pdf` §4) are rejected per `EDS-26 Rev 4` §5.3.2.
- **Soil and Concrete Thermal Resistivity (`0.60 K·m/W` and `0.55 K·m/W`):** Per `GEO-4210-T_thermal_resistivity_report.pdf` §3.1–3.2 and `E-619_duct_bank_sections.dxf`, `DB-1` and `DB-2` trenches are backfilled for their full width and depth with fluidised thermal backfill (`0.60 K·m/W`) around a 3000 psi concrete encasement (`0.55 K·m/W`). Per `EDS-26 Rev 4` §5.3.3, the backfill resistivity (`0.60 K·m/W`) governs the earth and mutual-heating terms, and the native sandy clay resistivity (`0.95 K·m/W` in `GEO-4210-T` §2) is rejected.
- **Interior Space Ambient Temperatures (`40 °C` and `45 °C`):** Per `M-501-C` §2, circuits routed through Mechanical Room 104 (`F-01`, `B-11`..`B-15`) and Fire Pump Room 108 (`F-03`) are evaluated at **`45 °C`** ambient; all other interior raceway circuits are evaluated at **`40 °C`** ambient.

---

## 3. Voltage-Drop Budget Allocation, Starting Point, and Low-Voltage Transformer Rule

- **Starting Point (`vd_start_point`):** Per `site/WRPU_service_availability_letter.pdf` (`WRPU-2026-0412`, §2), Whitmore Ridge Public Utilities owns and maintains pad-mounted transformer `T-1` (`1500 kVA`), and government ownership begins at the secondary lugs of `T-1`. Per `UFC 3-501-01` §3-2.7.4.1 and `EDS-26 Rev 4` §4.1, the secondary lugs of `T-1` are the starting point of the voltage-drop calculation (`SE-1` is the first segment).
- **Service-Entrance Voltage-Drop Load (`SE-1`):** Per `EDS-26 Rev 4` §2.3, `UFC 3-501-01` §3-2.7.4.3.1 sets the voltage-drop load of a service entrance to 100% of the service device rating (**`1600 A`** on `MSB-1`), whereas §3-2.7.4.3.2 references the required bus ampacity (**`2000 A`**). This design adopts **`1600 A`** (`VD(SE-1) = 1.04%`, `drop_v = 5.01 V`). (Even at `2000 A`, `VD(SE-1) = 1.30%`, and every feeder chain remains `<= 3.04%`).
- **No Reset at Low-Voltage Transformer `K-13` (`transformer_reset = false`):** Per `UFC 3-501-01` §3-2.7.4.5.3 and `EDS-26 Rev 4` §4.1, voltage-drop counts do **not** restart at low-voltage dry-type transformer `K-13` (`75 kVA`, `480V–208Y/120V`).
- **Branch Circuits Inheriting Upstream Budget (`18 branch/motor circuits total, including 10 downstream of LV transformer K-13`):**
  - **10 circuits on `LP-1` (`B-01` through `B-10`, downstream of `K-13`)** inherit the 4-link feeder chain `SE-1 (1.04%) + F-02 (0.36%) + F-06 (0.16%) + F-07 (1.20%) = 2.77% <= 3.0%`. To keep cumulative voltage drop `<= 5.0%` (`branch VD <= 2.23%`), `B-01`, `B-03`, `B-04`, `B-05`, `B-08` are sized at `#8 AWG CU` and `B-02`, `B-06`, `B-07` at `#6 AWG CU` (with proportional EGC scaling per `NFPA 70` 250.122(B)), giving a maximum cumulative voltage drop of **`4.86%`** (on `B-06` and `B-09`).
  - **3 circuits on `DP-3` (`B-16` through `B-18` in Building 4212)** inherit `SE-1 (1.04%) + F-05 (1.54%) = 2.58% <= 3.0%`. Because `CMP-1` (`B-17`) accepts at most a single `#6 AWG` conductor per terminal (`VD(B-17) = 2.35%`), `F-05` (`716 ft` in `DB-2`) is sized at `3 sets of 600 kcmil AL` (`VD = 1.54%`, `250 kcmil CU` EGC), limiting cumulative voltage drop at `CMP-1` (`B-17`) to **`4.93% <= 5.0%`**. Circuit `B-18` (`194 ft` lighting circuit) is upsized to `#8 AWG CU` (`VD = 1.97%`, `cum_vd = 4.55% <= 5.0%`).
  - **5 motor feeders on `MCC-1` (`B-11` through `B-15`)** inherit `SE-1 (1.04%) + F-01 (1.53%) = 2.58% <= 3.0%`, with maximum cumulative voltage drop of **`3.77% <= 5.0%`** (on `B-15`).
- **Equipment-Specific Limits (`F-03`, `F-09`, `F-11`):**
  - **Fire Pump (`F-03`, `EDS-26 Rev 4` §4.6.3 & `NFPA 70` Art. 695):** With `#1 AWG CU`, running voltage drop is `0.30%` (`cumulative = 1.34% <= 5.0%`), and locked-rotor (`543 A` at `PF = 0.35`) drop is `1.01%` (`cumulative = 2.05% <= 15.0%`).
  - **Elevator (`F-11`, `EDS-26 Rev 4` §4.6.2):** With `#3 AWG CU`, feeder own voltage drop is `1.16% <= 2.0%` (`cumulative = 2.21% <= 5.0%`).
  - **ASD/VFD (`F-09`, `EDS-26 Rev 4` §4.6.4):** Reactance is multiplied by `1.25` (`X = 1.25 * 0.0375 = 0.0469 ohm/kft`), yielding `VD(F-09) = 1.00%` (`cumulative = 2.41% <= 5.0%`).

---

## 4. Service-Entrance Sizing Decision (`SE-1`)

Although `MSB-1` has a `1600 A` main breaker, its bus ampacity is **`2000 A`** (`P-4210_equipment_schedule.xlsx` and `E-601_one_line_diagram.dxf`). Under **UFC 3-501-01 §3-2.3.3** and **EDS-26 Rev 4 §2.2**, low-voltage service-entrance conductors must be sized for **100% of the service switchboard bus rating (`2000 A`)**. Thus `SE-1` is sized for `design_current_a = 2000 A` using **6 parallel sets of `500 kcmil CU`** (`348.11 A/set * 6 = 2088.66 A >= 2000 A`) with a **`4/0 AWG CU`** EGC per duct (`EDS-26 Rev 4` §5.7, `NFPA 70` Table 250.122 for `1600 A` main device).

---

## 5. Underground Duct-Bank Assignment and Mutual-Heating Consequence

- **Service Duct Bank `DB-1` (`10 of 12 ducts available`):** Sheet `E-619_duct_bank_sections.dxf` shows `DB-1` as a `3 rows x 4 columns` (`12-duct`) concrete-encased `5 in EPC-40` bank (`9 in` horizontal/vertical center-to-center spacing, `30 in` cover to top of encasement, `39.6 in x 29.6 in` concrete envelope). Per `E-619`, **`D11` (spare - owner reserve) and `D12` (existing site lighting feeder) are reserved**, leaving **10 ducts (`D1` through `D10`)** available.
- **Thermal Assignment in `DB-1` (`mutual_heating_rise_k = 31.09 K`):**
  - `SE-1` (`6 sets of 500 kcmil CU`, operating current `1732 / 6 = 288.67 A/set`, `W_j = 25.00 W/m`): assigned to columns 1 and 2 (`D1, D2, D5, D6, D9, D10`).
  - `F-10` (`2 sets of 500 kcmil AL`, operating current `432 / 2 = 216.00 A/set`, `W_j = 23.03 W/m`): assigned to column 4 (`D4, D8`), leaving column 3 (`D3, D7`) empty as a thermal buffer.
  - Under the Neher-McGrath formulation in `EDS-26 Rev 4` §5.3 (`T_a,e = 27.45 °C`, `T_c = 90 °C`, `rho_e = 0.60 K·m/W`, `rho_c = 0.55 K·m/W`, `LF = 1.0`), the worst-case mutual-heating rise in `DB-1` is **`31.09 K`** (at interior duct `D5` of `SE-1`), yielding `corrected_ampacity_a = 348.11 A/set` on `SE-1` (`6 * 348.11 = 2088.66 A >= 2000 A`). On `F-10` (`D4, D8`), mutual heating from `SE-1` produces **`23.53 K`** (at `D8`), yielding `corrected_ampacity_a = 302.25 A/set` (`2 * 302.25 = 604.50 A >= 600 A`).
- **Duct Bank `DB-2` (`F-05` in `E1, E2, E3`):** Sheet `E-619` shows `DB-2` as a `2x2` (`4-duct`) `4 in EPC-40` bank (`8 in` spacing, `19.5 in x 19.5 in` envelope) with **`E4` reserved for communications**, leaving **3 ducts (`E1, E2, E3`)** available. `F-05` (`3 sets of 600 kcmil AL`, operating current `281 / 3 = 93.67 A/set`) occupies **`E1, E2, E3`**, experiencing `Delta_T_m = 1.54 K` (`i_therm = 399.65 A/set`), capped by the `75 °C` termination limit at **`336.00 A/set`**.

---

## 6. Roof Cable Tray, Material, Termination Rating, and Standardisation Decisions

- **Roof Ladder Tray `CT-R1` (`tray_sum_od_in = 12.206 in`, `ccc = 18`):** All four rooftop HVAC feeders (`F-04` and `F-12` at `2 sets of 4/0 AL` each; `F-08` and `F-13` at `1 set of 4/0 AL` each) share `CT-R1` (`6 sets = 18` current-carrying conductors total, `k_t = 1 + 0.06*(18 - 3) = 1.90`, `corrected_ampacity_a = 171.93 A/set`). The sum of all 24 cable ODs (18 phase + 6 EGC) is **`12.206 in <= 16.20 in`** (`90%` of the `18 in` usable tray width per `EDS-26 Rev 4` §6.3.2 and `26_05_33` §2.3).
- **Termination Temperature Limit (`EDS-26 Rev 4` §5.5 & `UFC 3-520-01` §3-6.3.1):** Every circuit with `ocpd_a <= 100 A` (`B-01`..`B-10`, `B-13`..`B-18`) as well as `F-07` (connected to `LP-1` with listed `60 °C` lugs) is capped by the `60 °C` ampacity column; circuits with `ocpd_a > 100 A` and `75 °C` lugs are capped by the `75 °C` column.
- **Standardisation (`distinct_large_sizes = 5`):** Across the entire project, exactly **5 distinct phase-conductor sizes larger than `#1 AWG`** are used (`4/0`, `300 kcmil`, `400 kcmil`, `500 kcmil`, `600 kcmil`), satisfying `EDS-26 Rev 4` §3.4.2 (`<= 5` sizes).

---

## 7. Cost Ledger Summary (Material and Labour)

Total installed conductor length across all 32 circuits (phase conductors plus copper EGCs) is **`40,888 ft`** (`>= 38,000 ft`), qualifying for the **`-6%` campus quantity break** (`Cascadia_Wire_price_list_2026.csv`) on all conductor material and labour:

| Cost Category | Quantity | Unit | Material (USD) | Labour (USD) | Total Installed (USD) |
|---|---:|---|---:|---:|---:|
| Conductors (Gross before quantity break) | 40,888 | ft | $74,880.24 | $24,464.89 | $99,345.13 |
| Campus Quantity Break (`-6%` on `>= 38,000 ft`) | 40,888 | ft | $-4,492.81 | $-1,467.90 | $-5,960.71 |
| **Conductors (Net of `-6%` Quantity Break)** | **40,888** | **ft** | **$70,387.43** | **$22,996.99** | **$93,384.42** |
| **Compression Terminations (`per set per end`)** | **90** | **set-end** | **$5,105.26** | **$4,504.06** | **$9,609.32** |
| **Interior Rigid Steel Conduit (`RMC`)** | **4,257** | **ft** | **$21,406.08** | **$26,183.52** | **$47,589.60** |
| **Total Installed Package Cost** | **1** | **ls** | **$96,898.77** | **$53,684.57** | **$150,583.34** |
